import React from "react";

function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>Bienvenue dans FamOrganiz</h1>
      <p>Votre application familiale pour gérer les repas, les plannings et les tâches.</p>
    </div>
  );
}

export default App;
